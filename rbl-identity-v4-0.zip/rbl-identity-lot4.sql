-- RBL Identity · Lot 4 : templates premium
-- À lancer une seule fois dans Supabase > SQL Editor > New query > Run

-- 1. Chaque cliente a une offre : gratuite par défaut
alter table public.profiles add column if not exists plan text not null default 'free';

-- 2. Seule Lyliie (admin) peut activer ou retirer le premium
create or replace function public.set_plan(target uuid, new_plan text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then
    raise exception 'Réservé à Lyliie';
  end if;
  if new_plan not in ('free', 'premium') then
    raise exception 'Offre inconnue';
  end if;
  update public.profiles set plan = new_plan where id = target;
end;
$$;

revoke all on function public.set_plan(uuid, text) from public;
grant execute on function public.set_plan(uuid, text) to authenticated;
